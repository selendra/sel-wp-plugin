


function hello() {
	alert("hello");
}