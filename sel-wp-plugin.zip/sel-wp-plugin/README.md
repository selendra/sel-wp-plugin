# sel-wp-plugin

Selendra WordPress Login UI to work with Selendra ID App.
