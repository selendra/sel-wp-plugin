<div class="bg-sky-50 my-4">
    <div class="mx-auto py-2 text-black truncate text-center">
        <span class="text-sm">URL verification:</span>
        <a href='https://accounts.selendra.com' class='no-underline text-sky-500 font-medium text-sm' target='_blank'>https://accounts.selendra.com</a>
    </div>
</div>