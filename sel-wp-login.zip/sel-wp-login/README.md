=== Selendra WordPress Login ===
This is plugin to enable Login feature with Selendra Student ID App.