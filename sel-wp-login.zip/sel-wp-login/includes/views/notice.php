<div class='notice'>
    <span>URL verification:</span>
    <a href='https://accounts.selendra.com' class='alert-link text-decoration-none' target='_blank'>https://accounts.selendra.com</a>
</div>