<div class="tab">
    <button class="button-type active" id="with-email"><?php esc_html_e('Email', SEL_WP_LOGIN_KEY_NAME); ?></button>
    <button class="button-type" id="with-phone"><?php esc_html_e('Phone Number', SEL_WP_LOGIN_KEY_NAME); ?></button>
</div>