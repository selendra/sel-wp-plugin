<nav>
    <a href='#' id="logo">
        <img src='wp-content/uploads/2022/05/selendra-black.png' alt='' height='56' class='d-inline-block align-text-top'>
    </a>
    <a id="darkmode">
        <img class='image img-flip' src='wp-content/plugins/wp-login/img/cloud-moon.svg' width='48' height='48'>
    </a>
</nav>